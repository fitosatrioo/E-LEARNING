﻿Imports DevExpress.Web
Imports System.Reflection.MethodBase
Imports System.Drawing
Imports System.IO
Imports DevExpress.Web.Data
Imports System.Data.SqlClient

Public Class el_exam
    Inherits System.Web.UI.Page
    Dim dr_user As DataRow
    Dim str As String
    Dim strg As String
    Dim strg2 As String
    Dim salah As er_custom
    Dim waktu_query As New Stopwatch
    Dim waktu_page As New Stopwatch
    Dim dt, dtj As New DataTable
    Dim dt2 As New DataTable
    Dim str_menu As String = ",2,"
    Dim dr As DataRow
    Dim idrec As Int64
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("id_paket") Is Nothing Then
            Response.Redirect("pilihan_quiz.aspx")
        End If
        'If Not Me.IsPostBack Then
        '    'Me.isi_data()
        '    Me.BindRepeater()
        'End If

    End Sub



    Private Sub isi_data()
        strg = "select * from el_tbl_soal WHERE id_paket='" + Request.QueryString("id_paket") + "'"

        Me.salah = Mod_Utama.isi_data(dt, strg, "id_soal", waktu_query)
        If salah.er_hasil <> "" Then

            Exit Sub
        End If

        strg = "select * from el_tbl_paket WHERE id_paket='" + Request.QueryString("id_paket") + "'"
        Me.salah = Mod_Utama.isi_data(dtj, strg, "id_paket", waktu_query)
        If salah.er_hasil <> "" Then

            Exit Sub
        End If

        For Each dtjr As DataRow In dtj.Rows
            Me.jenis.Text = dtjr("jenis_test")
        Next


        For Each dtr As DataRow In dt.Rows

            strg2 = "select * from el_tbl_jawaban where id_soal = " & dtr("id_soal") & ""

            Me.salah = Mod_Utama.isi_data(dt2, strg2, "id_jawaban", waktu_query)
            If salah.er_hasil <> "" Then

                Exit Sub
            End If
            If dtr("jenis_soal") = "pg" Then
                If dtr("tipe_soal") = "gambar" Then
                    str = str & "<div>"
                    str = str & "<img src='gambar/" & dtr("nama_file") & "' width='200px'  />"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "</div>"
                ElseIf dtr("tipe_soal") = "text" Then
                    str = str & "<div>"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "</div>"
                ElseIf dtr("tipe_soal") = "link" Then
                    str = str & "<div>"
                    str = str & "<iframe style='width: 450px; height: 200px' src='https://www.youtube.com/embed/" & dtr("nama_file") & "' frameborder='0' allowfullscreen></iframe>"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "</div>"
                End If
            Else
                If dtr("tipe_soal") = "gambar" Then
                    str = str & "<div>"
                    str = str & "<img src='gambar/" & dtr("nama_file") & "' width='200px'  />"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "<input name='txt_soal" & dtr("id_soal") & "' type='text' >"
                    str = str & "</div>"
                ElseIf dtr("tipe_soal") = "text" Then
                    str = str & "<div>"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<textarea style='width: 450px; height: 180px' name='id_soal" & dtr("id_soal") & "' placeholder='Jawabanmu'></textarea>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "</div>"
                ElseIf dtr("tipe_soal") = "link" Then
                    str = str & "<div>"
                    str = str & "<iframe width='560' height='315' src='https://www.youtube.com/embed/" & dtr("nama_file") & "' frameborder='0' allowfullscreen></iframe>"
                    str = str & "<label for='exampleFormControlInput1'>" & dtr("soal") & "</label>"
                    str = str & "<input name='tx_soal" & dtr("id_soal") & "' type='hidden' value='" & dtr("id_soal") & "'>"
                    str = str & "<input name='" & dtr("id_soal") & "' type='text' >"
                    str = str & "</div>"
                End If
            End If


            For Each dts As DataRow In dt2.Rows

                str = str & "<div>"
                str = str & ""
                str = str & "<input id='id_soal' name='id_soal" & dts("id_soal") & "' type='radio' for='radio' value='" & dts("opsi") & "'> <label for='exampleFormControlInput1'>" & dts("opsi") & ". " & dts("jawaban") & "</label>"
                str = str & "</div>"


            Next
            str = str & "<br />"

        Next


        Me.su57.InnerHtml = str


    End Sub

    Private Sub el_exam_Init(sender As Object, e As EventArgs) Handles Me.Init
        Try
            idrec = Request.QueryString("idrec")
        Catch ex As Exception
            Response.Redirect("materi.aspx")
        End Try
        dr_user = Session("dr_user")
        Me.isi_data()
    End Sub

    Private Sub Jika_error(er_str As String, er_hasil As String, er_menu As String, nopesan As Integer)
        salah.er_str = er_str
        salah.er_menu = er_menu
        salah.er_waktu = Mod_Utama.str_waktu(Me.waktu_query, Me.waktu_page)
        Session("error") = salah

        Select Case nopesan
            Case 1
                Mod_Utama.tampil_error(Me, "Terjadinya kesalahan pada Query, harap kirim laporan ke MIS via email")
            Case Else
                Mod_Utama.tampil_error(Me, "Terjadinya kesalahan pada Proses, harap kirim laporan ke MIS via email")
        End Select
    End Sub


    Protected Sub btnselesai_ServerClick1(sender As Object, e As EventArgs)


    End Sub


    Private Sub el_exam_PreInit(sender As Object, e As EventArgs) Handles Me.PreInit
        Me.waktu_page.Start()
    End Sub

    Private Sub test_Click(sender As Object, e As EventArgs) Handles test.Click
        strg = "select * from el_tbl_soal WHERE id_paket='" + Request.QueryString("id_paket") + "'"

        Me.salah = Mod_Utama.isi_data(dt, strg, "id_soal", waktu_query)
        If salah.er_hasil <> "" Then

            Exit Sub
        End If
        For Each dtr As DataRow In dt.Rows
            Dim conn As SqlConnection = New SqlConnection(Mod_Utama.sql_str)
            conn.Open()

            Dim query As String = "INSERT INTO el_tbl_nilai (id_nilai, id_soal, jawaban_user) VALUES ((SELECT ISNULL(MAX(id_nilai), 0) + 1 FROM el_tbl_nilai), @tx_soal, @id_soal)"
            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@id_soal", Request.Form("id_soal" & dtr("id_soal") & ""))

            cmd.Parameters.AddWithValue("@tx_soal", Request.Form("tx_soal" & dtr("id_soal") & ""))




            cmd.ExecuteNonQuery()
            conn.Close()
        Next

        Response.Redirect("pilihan_quiz.aspx")

        'Dim SelectedValue As String = Request.Form("id_soal")

        '    str = "insert into tbl_ruang ("
        '    str = str & "id_ruang, no_ruang , nama_ruang "
        '    str = str & ") values ("
        '    str = str & "(select isnull(max(id_ruang),0)+1 from tbl_soal),"
        '    str = str & "'" & SelectedValue & "', "
        '    str = str & "'" & SelectedValue & "') "
        '    salah.er_hasil = Mod_Utama.exec_sql(str)





    End Sub



    'Private Sub BindRepeater()
    '    Dim conn As SqlConnection = New SqlConnection(Mod_Utama.sql_str)
    '    Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM el_tbl_soal WHERE id_paket='" + Request.QueryString("id_paket") + "'", conn)

    '    conn.Open()
    '    Dim reader As SqlDataReader = cmd.ExecuteReader()
    '    reader.Read()


    '    tx_soal.Text = reader("soal").ToString()

    '    reader.Close()
    '    conn.Close()
    'End Sub

    'Private Sub BindRepeater()
    '    'Dim id_dept As String = Session("id_user")
    '    Dim id_paket As String = "1"


    '    Dim conn As SqlConnection = New SqlConnection(Mod_Utama.sql_str)

    '    Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM el_tbl_soal WHERE id_paket = ' " + Request.QueryString("id_paket") + " ' ", conn)
    '    Dim cmd2 As SqlCommand = New SqlCommand("SELECT * FROM el_tbl_jawaban WHERE id_paket = ' " + Request.QueryString("id_paket") + " ' ", conn)

    '    Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
    '    Dim sda2 As SqlDataAdapter = New SqlDataAdapter(cmd2)

    '    Dim dt1 As DataTable = New DataTable()
    '    Dim dt2 As DataTable = New DataTable()

    '    sda.Fill(dt1)
    '    sda2.Fill(dt2)

    'Repeater1.DataSource = dt1
    'Repeater1.DataBind()

    'Repeater2.DataSource = dt2
    'Repeater2.DataBind()



    'End Sub

End Class