﻿Imports System.Data.SqlClient

Public Class pilihan_materi2
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("id_dept") Is Nothing Then
            Response.Redirect("pilihan_materi.aspx")
        End If
        If Not Me.IsPostBack Then
            'Me.isi_data()
            Me.BindRepeater()
        End If
        'Me.isi_data()
    End Sub

    Private Sub BindRepeater()
        'Dim id_dept As String = Session("id_user")
        Dim id_dept As String = "1"


        Dim conn As SqlConnection = New SqlConnection(Mod_Utama.sql_str)
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM tbl_materi WHERE id_dept = ' " + Request.QueryString("id_dept") + " ' ", conn)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)

        Dim dt1 As DataTable = New DataTable()

        sda.Fill(dt1)

        Repeater1.DataSource = dt1
        Repeater1.DataBind()
    End Sub

End Class