﻿Imports DevExpress.Web
Imports System.Reflection.MethodBase
Imports System.Drawing
Imports System.IO
Imports DevExpress.Web.Data
Imports System.Data.SqlClient
Public Class nilai
    Inherits System.Web.UI.Page
    Dim dr_user As DataRow
    Dim str As String
    Dim strg As String
    Dim strg2 As String
    Dim salah As er_custom
    Dim waktu_query As New Stopwatch
    Dim waktu_page As New Stopwatch
    Dim dt, dtj As New DataTable
    Dim dt2 As New DataTable
    Dim str_menu As String = ",2,"
    Dim dr As DataRow
    Dim idrec As Int64
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            'Me.isi_data()
            Me.BindRepeater()
        End If
        'Me.isi_data()
    End Sub

    Private Sub nilai_Init(sender As Object, e As EventArgs) Handles Me.Init
        Try
            idrec = Request.QueryString("idrec")
        Catch ex As Exception
            Response.Redirect("materi.aspx")
        End Try
        dr_user = Session("dr_user")
        Me.isi_data()
    End Sub

    Private Sub isi_data()
        strg = "select SUM(el_tbl_soal.skor) as nilai from el_tbl_nilai INNER JOIN el_tbl_soal on el_tbl_nilai.id_soal = el_tbl_soal.id_soal AND el_tbl_nilai.jawaban_user = el_tbl_soal.jawaban"


        Me.salah = Mod_Utama.isi_data(dt, strg, "id_soal", waktu_query)
        If salah.er_hasil <> "" Then

            Exit Sub
        End If

        For Each dtjr As DataRow In dt.Rows
            Me.skor.Text = dtjr("nilai")
        Next




    End Sub

    Private Sub BindRepeater()
        'Dim id_dept As String = Session("id_user")
        Dim id_dept As String = "1"


        Dim conn As SqlConnection = New SqlConnection(Mod_Utama.sql_str)
        Dim cmd As SqlCommand = New SqlCommand("SELECT jawaban_user, skor, soal FROM el_tbl_nilai inner join el_tbl_soal ON el_tbl_nilai.id_soal = el_tbl_soal.id_soal ", conn)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)

        Dim dt1 As DataTable = New DataTable()

        sda.Fill(dt1)

        Repeater1.DataSource = dt1
        Repeater1.DataBind()
    End Sub
End Class